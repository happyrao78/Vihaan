#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun May  5 23:15:59 2019

@author: scion01
"""

sample_size = 10
dev_mode = True
train_mode = True